-- Davi Wilson, Cauã Euzébio, Wallacy Alvaran

CREATE DATABASE bdEscola;

USE bdEscola;

-- Tabela de Professores
CREATE TABLE tbProf (
    RP INT PRIMARY KEY,
    nome VARCHAR(300),
    data_nasc DATE,
    genero VARCHAR(100),
    titulacao VARCHAR(300)
);

-- Tabela de Cursos
CREATE TABLE Tbcurso (
    cod_cur INT PRIMARY KEY,
    carga_horaria_curso VARCHAR(100),
    nome_curso VARCHAR(100)
);

-- Tabela de Disciplinas
CREATE TABLE tbDisciplina (
    cod_disc INT PRIMARY KEY,
    carga_horario_disc varchar(100),
    nome_disc VARCHAR(100)
);

-- Tabela de Alunos
CREATE TABLE tbAluno (
    RA INT PRIMARY KEY,
    nome_aluno VARCHAR(100),
    data_nasc DATE,
    genero VARCHAR(20)
);

-- Tabela de Matrículas
CREATE TABLE tbMatricula (
    cod_Mat INT PRIMARY KEY,
    data_mat DATE
);

-- Tabela de Professores e Disciplinas

CREATE TABLE tbProfDisc (
    cod_disc INT,
    RP INT,
    data_aula DATE,
    FOREIGN KEY (cod_disc)
        REFERENCES tbDisciplina(cod_disc),
    FOREIGN KEY (RP)
        REFERENCES tbProf(RP)
);

-- Tabela de Notas
CREATE TABLE tbNota (
    id_nota INT PRIMARY KEY,
    nota_Aluno DECIMAL(4 , 2 ),
    RA INT,
    cod_disc INT,
    FOREIGN KEY (RA)
        REFERENCES tbAluno (RA),
    FOREIGN KEY (cod_disc)
        REFERENCES tbDisciplina (cod_disc)
);

INSERT INTO tbProf (RP, nome, data_nasc, genero, titulacao) VALUES
(1, 'Carlos Silva', '1980-05-12', 'M', 'Mestre'),
(2, 'Ana Souza', '1985-09-23', 'F', 'Doutora'),
(3, 'Pedro Santos', '1978-02-15', 'M', 'Especialista'),
(4, 'Mariana Costa', '1990-11-08', 'F', 'Mestre'),
(5, 'Lucas Oliveira', '1983-07-19', 'M', 'Graduado'),
(6, 'Fernanda Lima', '1987-04-30', 'F', 'Mestre');


INSERT INTO tbDisciplina (cod_disc, carga_horario_disc, nome_disc) VALUES
(1, '80', 'Banco de Dados'),
(2, '60', 'Programacao'),
(3, '40', 'Matematica'),
(4, '60', 'Redes de Computadores'),
(5, '80', 'Desenvolvimento Web'),
(6, '60', 'Sistemas Operacionais'),
(7, '40', 'Logica de Programacao'),
(8, '80', 'Engenharia de Software');


INSERT INTO tbAluno (RA, nome_aluno, data_nasc, genero) VALUES
(1001, 'Joao Mendes', '2008-03-14', 'M'),
(1002, 'Beatriz Lima', '2007-07-22', 'F'),
(1003, 'Gabriel Rocha', '2008-01-09', 'M'),
(1004, 'Julia Ferreira', '2007-12-05', 'F'),
(1005, 'Matheus Almeida', '2008-06-18', 'M'),
(1006, 'Larissa Gomes', '2007-04-11', 'F'),
(1007, 'Rafael Costa', '2008-09-25', 'M'),
(1008, 'Camila Ribeiro', '2007-02-17', 'F'),
(1009, 'Pedro Henrique', '2008-08-03', 'M'),
(1010, 'Mariana Alves', '2007-10-29', 'F'),
(1011, 'Lucas Martins', '2008-05-20', 'M'),
(1012, 'Isabela Carvalho', '2007-06-08', 'F'),
(1013, 'Felipe Araujo', '2008-11-12', 'M'),
(1014, 'Amanda Barros', '2007-01-31', 'F'),
(1015, 'Gustavo Nunes', '2008-04-07', 'M'),
(1016, 'Leticia Cardoso', '2007-09-14', 'F'),
(1017, 'Bruno Teixeira', '2008-02-26', 'M'),
(1018, 'Sofia Moreira', '2007-08-19', 'F'),
(1019, 'Daniel Castro', '2008-07-02', 'M'),
(1020, 'Isadora Mendes', '2007-03-23', 'F');


INSERT INTO tbMatricula (cod_Mat, data_mat) VALUES
(1, '2026-01-10'),
(2, '2026-01-11'),
(3, '2026-01-12'),
(4, '2026-01-13'),
(5, '2026-01-14'),
(6, '2026-01-15'),
(7, '2026-01-16'),
(8, '2026-01-17'),
(9, '2026-01-18'),
(10, '2026-01-19');



INSERT INTO tbProfDisc (cod_disc, RP, data_aula) VALUES
(1, 1, '2026-02-02'),
(2, 2, '2026-02-03'),
(3, 3, '2026-02-04'),
(4, 4, '2026-02-05'),
(5, 5, '2026-02-06'),
(6, 6, '2026-02-09');




INSERT INTO tbNota (id_nota, nota_Aluno, RA, cod_disc) VALUES
(1, '8.5', 1001, 1),
(2, '9.0', 1001, 2),
(3, '7.5', 1002, 1),
(4, '8.0', 1003, 3),
(5, '9.5', 1004, 5),
(6, '6.5', 1005, 2),
(7, '8.0', 1006, 4),
(8, '7.0', 1007, 6),
(9, '9.0', 1008, 7),
(10, '8.5', 1009, 8),
(11, '7.5', 1010, 1),
(12, '9.0', 1011, 5),
(13, '6.0', 1012, 3),
(14, '8.0', 1013, 2),
(15, '9.5', 1014, 8),
(16, '7.0', 1015, 6);


select * from tbProfDisc;
SELECT COUNT(*) AS total_alunos FROM tbAluno;
SELECT COUNT(*) AS total_disciplinas FROM tbDisciplina;
SELECT COUNT(*) AS total_professores FROM tbProf;
SELECT COUNT(*) AS total_matriculas FROM tbMatricula;
SELECT COUNT(*) AS total_aulas FROM tbProfDisc;
SELECT COUNT(*) AS total_notas FROM tbNota;




