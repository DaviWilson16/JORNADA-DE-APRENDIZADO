-- ALUNO: DAVI WILSON MATOS SECKLER
-- TURMA: 1 INFO NET
-- ATIVIDADE PRÁTICA: CRIAÇÃO E MANIPULAÇÃO DE BANCO DE DADOS
-- BANCO DE DADOS: CursoX
-- Compatível com MySQL

CREATE DATABASE IF NOT EXISTS CursoX;
USE CursoX;

-- 1. Criação das tabelas

CREATE TABLE IF NOT EXISTS Alunos (
    aluno_cod INT PRIMARY KEY,
    aluno_nome VARCHAR(100) NOT NULL,
    aluno_endereco VARCHAR(150),
    aluno_cidade VARCHAR(80)
);

CREATE TABLE IF NOT EXISTS Disciplina (
    dis_cod INT PRIMARY KEY,
    dis_nome VARCHAR(100) NOT NULL,
    dis_carga INT NOT NULL,
    dis_professor VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS Professores (
    prof_cod INT PRIMARY KEY,
    prof_nome VARCHAR(100) NOT NULL,
    prof_endereco VARCHAR(150),
    prof_cidade VARCHAR(80)
);

-- 2. Inserção de 10 alunos

INSERT INTO Alunos (aluno_cod, aluno_nome, aluno_endereco, aluno_cidade) VALUES
(1, 'Lucas Almeida', 'Rua das Flores, 120', 'São Paulo'),
(2, 'Mariana Souza', 'Rua Brasil, 45', 'Santo André'),
(3, 'Pedro Santos', 'Avenida Central, 300', 'São Paulo'),
(4, 'Ana Oliveira', 'Rua das Acácias, 78', 'Guarulhos'),
(5, 'Gabriel Costa', 'Rua do Sol, 90', 'Osasco'),
(6, 'Julia Ferreira', 'Rua Azul, 215', 'São Paulo'),
(7, 'Rafael Lima', 'Avenida Paulista, 500', 'São Paulo'),
(8, 'Beatriz Rocha', 'Rua Verde, 32', 'Diadema'),
(9, 'Matheus Gomes', 'Rua das Palmeiras, 410', 'Mauá'),
(10, 'Isabela Martins', 'Rua Nova, 65', 'Santo André');

-- 3. Inserção de 5 disciplinas distintas

INSERT INTO Disciplina (dis_cod, dis_nome, dis_carga, dis_professor) VALUES
(1, 'Banco de Dados', 80, 'Mariana Costa'),
(2, 'Programação Web', 100, 'Carlos Mendes'),
(3, 'Matemática', 60, 'Fernanda Alves'),
(4, 'Inglês', 40, 'Roberto Lima'),
(5, 'Design Digital', 60, 'Mariana Costa');

-- 4. Inserção de 5 professores distintos

INSERT INTO Professores (prof_cod, prof_nome, prof_endereco, prof_cidade) VALUES
(1, 'Mariana Costa', 'Rua A, 100', 'São Paulo'),
(2, 'Carlos Mendes', 'Rua B, 200', 'Guarulhos'),
(3, 'Fernanda Alves', 'Rua C, 300', 'Santo André'),
(4, 'Roberto Lima', 'Rua D, 400', 'São Paulo'),
(5, 'Paulo Ribeiro', 'Rua E, 500', 'Osasco');

-- 5. Atualização: acrescenta 10 horas à carga horária de todas as disciplinas
UPDATE Disciplina
SET dis_carga = dis_carga + 10;

-- 6. Exclusão: apaga as disciplinas ministradas pela professora Mariana Costa
DELETE FROM Disciplina
WHERE dis_professor = 'Mariana Costa';

-- Consultas opcionais para conferir os dados finais
SELECT * FROM Alunos;
SELECT * FROM Disciplina;
SELECT * FROM Professores;
